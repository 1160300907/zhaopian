﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using AForge;
using AForge.Video;
using AForge.Video.DirectShow;
using AForge.Imaging;
using AForge.Imaging.Filters;
using System.IO;

namespace Camera
{
    public partial class Test : Form
    {
        private FilterInfoCollection videoDevices;
        private int a = 0;
        public Test()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                    throw new ApplicationException();

                foreach (FilterInfo device in videoDevices)
                {
                    tscbxCameras.Items.Add(device.Name);
                }

                tscbxCameras.SelectedIndex = 0;
            }
            catch (ApplicationException)
            {
                tscbxCameras.Items.Add("No local capture devices");
                videoDevices = null;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CameraConn();
        }

        //连接摄像头
        private void CameraConn()
        {
            VideoCaptureDevice videoSource = new VideoCaptureDevice(videoDevices[tscbxCameras.SelectedIndex].MonikerString);
            videoSource.DesiredFrameSize = new Size(1920, 1080);
            videoSource.DesiredFrameRate = 1;

            videPlayer.VideoSource = videoSource;
            videPlayer.Start();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            videPlayer.SignalToStop();
            videPlayer.WaitForStop();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            toolStripButton2_Click(null, null);
        }

        /// <summary>
        /// 保存图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            string filepath = "testqxy";
            filepath = "星期"+textBox1.Text + "第"+textBox2.Text+"节课"+textBox3.Text+"老师";
            System.Drawing.Image img = new Bitmap(videPlayer.Width, videPlayer.Height);
            videPlayer.DrawToBitmap((Bitmap)img, new Rectangle(0, 0, videPlayer.Width, videPlayer.Height));
            if(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                ;
            }
            else
            {
                if (a >= 100000)
                    a = 0;
                a++;
                bool exist = System.IO.Directory.Exists(filepath);
                if (exist == false)
                {
                    //怎么新建一个文件夹
                    Directory.CreateDirectory(filepath);
                }
                string filename = filepath + "\\" + a + ".bmp";
                img.Save(filename, ImageFormat.Bmp);
            }

        }

        private void tscbxCameras_Click(object sender, EventArgs e)
        {

        }

        private void videPlayer_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
